﻿$pathToConfig = "C:\tfs\1Team\IntApps\CoworkerNet\Trunk\Source\Coworkernet.Portal.OrderManager"
$configName = "Web.config"
$envs = @("BETA", "QA", "TRAINING", "STAGE", "PRODUCTION", "PREVIEW")
$configXml = [xml] (Get-Content "$pathToConfig\$configName")
$fromEmailString = $null
$toEmailString = $null
$batchJobEmailString = $null

$exceptionPublishers = $configXml.configuration.CdwExceptionManagement.publisher
foreach ($publisher in $exceptionPublishers) {
    if ($publisher.type -eq "Cdw.ExceptionManagement.Publishers.EmailPublisher,Cdw.ExceptionManagement") {
        $fromEmailString = $publisher.fromEmailAddress
        $toEmailString = $publisher.toEmailAddresses
    }
}

$appSettings = $configXml.configuration.appSettings.add
foreach ($add in $appSettings) {
    if ($add.key -eq "Cdw.Windows.BatchJob.CompletionNotification.FromEmailAddress") {
        $batchJobEmailString = $add.value
    }
}

foreach ($environ in $envs) {
    if ($environ -eq "STAGE") {
        $envVal = "STAGING"
    }
    else {
        $envVal = $environ
    }

    $envConfigXml = [xml] (Get-Content C:\ConfigTransform\LegacyTransforms\$environ.config)
    if ($fromEmailString -ne $null) {
        $envConfigXml.configuration.CdwExceptionManagement.publisher.fromEmailAddress = $fromEmailString.Replace("[BETA]", "[$envVal]")
        $envConfigXml.configuration.CdwExceptionManagement.publisher.toEmailAddresses = $toEmailString.Replace("[BETA]", "[$envVal]")
    }

    if ($batchJobEmailString -ne $null) {
        $envConfigXml.configuration.appSettings.add.value = $batchJobEmailString.Replace("[BETA]", "[$envVal]")
    }

    $envConfigXml.Save("$pathToConfig\$($configName.Replace(".config", ".$environ.config"))")
}