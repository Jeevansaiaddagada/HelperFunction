﻿$pathToXAMLOutputSource = "\\bldnasprd\XLR\Ecomm\BatchJobs\Ecomm_WebCoworkernet\Ecomm-WebCoworkerNet-Cdw.Cw.Middle-Trunk\19.12.17.1.zip"
$pathTovNextOutputSource = "\\bldnasprd\XLR\Ecomm\Legacy\Web_CoworkerNet_Release\Cdw.Cw.Middle\8.78.101.12291\8.78.101.12291.Binaries.zip"

Remove-Item -Force -Recurse C:\Temp
New-Item -ItemType Directory -Path C:\Temp | Out-Null
New-Item -ItemType Directory -Path C:\Temp\XAML | Out-Null
New-Item -ItemType Directory -Path C:\Temp\vNext | Out-Null

Copy-Item -Force $pathToXAMLOutputSource -Destination C:\Temp\XAML\
Copy-Item -Force $pathTovNextOutputSource -Destination C:\Temp\vNext\

$xamlZip = Get-ChildItem C:\Temp\XAML
$vNextZip = Get-ChildItem C:\Temp\vNext

$xamlVersion = ([version] $xamlZip.Name.Replace(".Binaries.zip", "")).ToString()
$vNextVersion = ([version] $vNextZip.Name.Replace(".zip", "")).ToString()

$xamlExportFolder = New-Item -ItemType Directory -Path "C:\Temp\$xamlVersion"
$vnextExportFolder = New-Item -ItemType Directory -Path "C:\Temp\$vNextVersion"

Expand-Archive -Path $xamlZip.FullName -DestinationPath $xamlExportFolder
Expand-Archive -Path $vNextZip.FullName -DestinationPath $vnextExportFolder

$xamlExport = Get-ChildItem $xamlExportFolder -Recurse
$vNextExport = Get-ChildItem $vnextExportFolder -Recurse

###MAIN FILE COMPARSION###
foreach ($xamlFile in $xamlExport) {
    if ($xamlFile.FullName.Contains("ConfigXLD")) {
        continue;
    }

    $comparisonFile = $null
    $comparisonFile = Get-Item $xamlFile.FullName.Replace($xamlExportFolder.FullName, $vnextExportFolder.FullName) -ErrorAction SilentlyContinue
    if ($comparisonFile -eq $null) {
        Write-Output "$($xamlFile.Directory.Name)\$($xamlFile.name) does not exist in vNext Path"
    }
    else {
        if ($xamlFile.Extension -eq ".xml" -or $xamlFile.Extension -eq ".config") {
            $xamlXml = [xml] (Get-Content $xamlFile.FullName)
            $vNextXml = [xml] (Get-Content $comparisonFile.FullName)
            $result = Compare-Object $vNextXml.InnerXml $xamlXml.InnerXml
            if ($result -ne $null) {
                Write-Output "$($xamlFile.Directory.Name)\$($xamlFile.name) does not match content in vNext"
            }
            continue;
        }

        if (!$xamlFile.PSIsContainer -and ($xamlFile.Extension -eq ".dll" -or $xamlFile.Extension -eq ".exe")) {
            $xamlFileVersion = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($xamlFile.FullName).FileVersion
            $vNextFileVersion = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($comparisonFile.FullName).FileVersion
            if ($xamlFileVersion -ne $vNextFileVersion -and ($xamlFileVersion -ne $xamlVersion -or $vNextFileVersion -ne $vNextVersion)) {
                Write-Output "$($xamlFile.Directory.Name)\$($xamlFile.name) does not match version in vNext (XAML: $xamlFileVersion, vNext: $vNextFileVersion)"
                continue;
            }
        }

        if ($xamlFile.Length -ne $comparisonFile.Length -and $xamlFile.Extension -ne ".pdb") {
            Write-Output "$($xamlFile.Directory.Name)\$($xamlFile.name) does not match file size in vNext (XAML: $($xamlFile.Length), vNext: $($comparisonFile.Length))"
        }
    }
}

###PDB FILE COMPARSION###
$pdbOutput = C:\Projects\AssemblyVersionCompare\ConsoleAppShell.exe /Module=AssemblyVersionComparerModule /XAMLBuildPath=$($xamlZip.FullName) /VNextBuildPath=$($vNextZip.FullName) /LeaveFiles=true /SkipPrompts=true
if (!$pdbOutput.Contains("PDB mismatch count: 0")) {
    Write-Output "There are mismatch PDB files present between the build outputs."
}

###CONFIG FILES COMPARISON###
$xldConfigChildItems = Get-ChildItem $xamlExportFolder\ConfigXLD -Recurse
foreach ($xamlFile in $xldConfigChildItems) {
    if ($xamlFile.Extension -eq ".config") {
        $envName = $null
        switch ($xamlFile.Directory.Name) {
            "Beta" {
                $envName = "BETA"
                break;
            }
            "Qa" {
                $envName = "QA"
                break;
            }
            "Stage" {
                $envName = "STAGE"
                break;
            }
            "Train" {
                $envName = "TRAINING"
                break;
            }
            "Prod" {
                $envName = "PRODUCTION"
                break;
            }
            "Prod.DR" {
                $envName = "PRODUCTION"
                break;
            }
        }
        $comparisonFile = $null 
        $comparisonFile = Get-Item "$($vnextExportFolder.FullName)\Config\$($xamlFile.Name)_$envName" -ErrorAction SilentlyContinue

        if ($comparisonFile -eq $null) {
            $comparisonFile = Get-Item "$($vnextExportFolder.FullName)\bin\Config\$($xamlFile.Name)_$envName" -ErrorAction SilentlyContinue
        }

        if ($comparisonFile -eq $null) {
            Write-Output "$($xamlFile.Directory.Name)\$($xamlFile.name) does not exist in vNext Path"
        }
        else {
            $xamlXml = [xml] (Get-Content $xamlFile.FullName)
            $vNextXml = [xml] (Get-Content $comparisonFile.FullName)
            $result = Compare-Object $vNextXml.InnerXml $xamlXml.InnerXml
            if ($result -ne $null) {
                Write-Output "$($xamlFile.Directory.Name)\$($xamlFile.name) does not match content in vNext"
            }
        }
    }
}